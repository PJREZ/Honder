LOCAL_PATH := $(call my-dir)

###############################################################################
# ipad_charge
# Original upstream project :
#     https://github.com/mkorenkov/ipad_charge.git
###############################################################################

include $(CLEAR_VARS)

LOCAL_MODULE := ipad_charge
LOCAL_DESCRIPTION := Sends a specific command to the iPad and allow it to draw \
		     more than 500mA on the USB Bus.
LOCAL_CATEGORY_PATH := utils

LOCAL_LIBRARIES := libusb_1_0

LOCAL_SRC_FILES := \
	$(call all-c-files-under,.,.c)

LOCAL_COPY_FILES := \
	95-ipad_charge.rules:lib/udev/rules.d/

include $(BUILD_EXECUTABLE)
