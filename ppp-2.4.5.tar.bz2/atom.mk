
LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := ppp
LOCAL_DESCRIPTION := An implementation of the Point-to-point protocol. \
	See: http://ppp.samba.org \
	Don't forget to configure your kernel for ppp too!
LOCAL_CATEGORY_PATH := network
LOCAL_AUTOTOOLS_VERSION := 2.4.5
LOCAL_AUTOTOOLS_ARCHIVE := $(LOCAL_MODULE)-$(LOCAL_AUTOTOOLS_VERSION).tar.gz
LOCAL_AUTOTOOLS_SUBDIR := $(LOCAL_MODULE)-$(LOCAL_AUTOTOOLS_VERSION)

LOCAL_AUTOTOOLS_PATCHES := \
	pclinux_chat_build.patch \
	commit-3eb9e81.patch

LOCAL_AUTOTOOLS_MAKE_BUILD_ENV := $(AUTOTOOLS_CONFIGURE_ENV)
LOCAL_AUTOTOOLS_MAKE_BUILD_ARGS := COPTS="$(TARGET_GLOBAL_CFLAGS)"

LOCAL_AUTOTOOLS_MAKE_INSTALL_ENV := $(AUTOTOOLS_CONFIGURE_ENV)
LOCAL_AUTOTOOLS_MAKE_INSTALL_ARGS := DESTDIR="$(TARGET_OUT_STAGING)/usr"

define LOCAL_AUTOTOOLS_CMD_POST_CONFIGURE
	$(Q) sed -i -e 's/ -DIPX_CHANGE -DHAVE_MMAP//' $(PRIVATE_SRC_DIR)/pppd/Makefile
	$(Q) sed -i -e 's/HAVE_MULTILINK=y/\#HAVE_MULTILINK=y/' $(PRIVATE_SRC_DIR)/pppd/Makefile
	$(Q) sed -i -e 's/FILTER=y/\#FILTER=y/' $(PRIVATE_SRC_DIR)/pppd/Makefile
	$(Q) sed -i -e 's,(INSTALL) -s,(INSTALL) -p,' $(PRIVATE_SRC_DIR)/*/Makefile
	$(Q) sed -i -e 's,(INSTALL) -s,(INSTALL) -p,' $(PRIVATE_SRC_DIR)/pppd/plugins/*/Makefile
endef

define LOCAL_AUTOTOOLS_CMD_POST_CLEAN
	$(Q) rm -rf $(TARGET_OUT_STAGING)/usr/include/pppd
	$(Q) rm -rf $(TARGET_OUT_STAGING)/usr/lib/pppd/2.4.5
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/chat
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/pppoe-discovery
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/pppd
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/pppstats
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/pppdump
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/chat.8
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/pppd-radius.8
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/pppd-radattr.8
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/pppd.8
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/pppstats.8
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/share/man/man8/pppdump.8
endef

include $(BUILD_AUTOTOOLS)

