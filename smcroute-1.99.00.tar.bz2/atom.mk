# smcroute

# Archive is made from https://github.com/troglobit/smcroute
# on master, tag 1.99.0 from 2012-05-15
# on SHA1 2114949f39fcaed6fa26978facc10368eef09746

LOCAL_PATH := $(call my-dir)


include $(CLEAR_VARS)

LOCAL_MODULE := smcroute
LOCAL_DESCRIPTION := SMCRoute allows to manipulate the multicast routes of the Linux kernel.
LOCAL_CATEGORY_PATH := network

LOCAL_AUTOTOOLS_VERSION := 1.99.00
LOCAL_AUTOTOOLS_ARCHIVE := $(LOCAL_MODULE)-$(LOCAL_AUTOTOOLS_VERSION).tar.gz
LOCAL_AUTOTOOLS_SUBDIR := $(LOCAL_MODULE)-$(LOCAL_AUTOTOOLS_VERSION)/

LOCAL_AUTOTOOLS_PATCHES := \
	smcroute-1.99.00-INADDR_ANY_removal_no_leak_no_loop_forever.patch

# This prevent:
# at configure: "checking whether setpgrp takes no argument... configure: error: cannot check setpgrp when cross compiling"
# at link: "undefined reference to `rpl_malloc'"
LOCAL_AUTOTOOLS_CONFIGURE_ENV := \
	ac_cv_func_malloc_0_nonnull=yes \
	ac_cv_func_setpgrp_void=yes


LOCAL_AUTOTOOLS_MAKE_BUILD_ENV := \
	$(AUTOTOOLS_CONFIGURE_ENV)

LOCAL_AUTOTOOLS_MAKE_BUILD_ARGS := \
	CC="$(CCACHE) $(TARGET_CC)"

LOCAL_AUTOTOOLS_MAKE_INSTALL_ENV := \
	$(AUTOTOOLS_CONFIGURE_ENV)

LOCAL_AUTOTOOLS_MAKE_INSTALL_ARGS := \
	CC="$(CCACHE) $(TARGET_CC)" \
	DESTDIR="$(TARGET_OUT_STAGING)" \
	BINDIR="/usr/sbin"

define LOCAL_AUTOTOOLS_CMD_POST_CLEAN
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/smcroute
	$(Q) rm -f $(TARGET_OUT_STAGING)/usr/sbin/mcsender
endef

include $(BUILD_AUTOTOOLS)

