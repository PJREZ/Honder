
LOCAL_PATH := $(call my-dir)

###############################################################################
# usb-modeswitch
###############################################################################

include $(CLEAR_VARS)

LOCAL_MODULE := usb-modeswitch
LOCAL_MODULE_FILENAME := usb_modeswitch
LOCAL_CATEGORY_PATH := connectivity/usbmodem

LOCAL_REQUIRED_MODULES := \
	usb-modeswitch-data \
	jimtcl

UMS_BUILD_DIR := $(call local-get-build-dir)

LOCAL_SRC_FILES := \
	usb_modeswitch.c

LOCAL_DESTDIR := \
	usr/sbin

LOCAL_COPY_FILES := \
	$(UMS_BUILD_DIR)/usb_modeswitch.sh:lib/udev/usb_modeswitch \
	usb_modeswitch.conf:usr/share/usb_modeswitch.conf \
	$(UMS_BUILD_DIR)/usb_modeswitch.tcl:sbin/usb_modeswitch_dispatcher

$(UMS_BUILD_DIR)/usb_modeswitch.sh: $(LOCAL_PATH)/usb_modeswitch.sh
	@mkdir -p $(dir $@)
	$(Q) cp -f $< $@
	$(Q) patch $@ < $(PRIVATE_PATH)/lucie/usb_modeswitch.sh.patch

$(UMS_BUILD_DIR)/usb_modeswitch.tcl: $(LOCAL_PATH)/usb_modeswitch.tcl
	@mkdir -p $(dir $@)
	$(Q) cp -f $< $@
	$(Q) patch $@ < $(PRIVATE_PATH)/lucie/usb_modeswitch_dispatcher.patch
	$(Q) patch $@ < $(PRIVATE_PATH)/lucie/correct_syntax_errors_for_posix_regexp.patch

LOCAL_LIBRARIES := libusb

include $(BUILD_EXECUTABLE)

